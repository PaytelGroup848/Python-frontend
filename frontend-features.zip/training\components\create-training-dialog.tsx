"use client";

import { useEffect, useMemo, useState } from "react";

import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";

import {
    Button,
} from "@/components/ui/button";

import {
    Input,
} from "@/components/ui/input";

import {
    Label,
} from "@/components/ui/label";

import {
    Card,
    CardContent,
} from "@/components/ui/card";

import {
    CreateTrainingJobRequest,
} from "../types/training";

import {
    useCreateTrainingJob,
} from "../hooks/use-training-jobs";

import {
    useTrainingConfigurations,
} from "../hooks/use-training-configurations";

import {
    useModelVersions,
} from "@/features/models/hooks/use-model-versions";

import {
    useTokenizers,
} from "@/features/tokenizers/hooks/use-tokenizers";

import {
    useTokenizerVersions,
} from "@/features/tokenizers/hooks/use-tokenizer-versions";

/*
 Existing hooks
 (replace only if your project uses different names)

 import { useDatasets } from "...";
 import { useDatasetSnapshots } from "...";
 import { useTrainingProviders } from "...";
 import { useModels } from "...";
*/

interface CreateTrainingDialogProps {

    open: boolean;

    onOpenChange: (
        open: boolean,
    ) => void;

}

const DEFAULT_FORM: CreateTrainingJobRequest = {

    dataset_id: 0,

    dataset_snapshot_id: 0,

    training_provider_id: 0,

    training_configuration_id: 0,

    base_model_id: 0,

    base_model_version_id: 0,

    tokenizer_version_id: null,

    training_type: "",

    priority: 1,

    created_by: "",

};

export function CreateTrainingDialog({

    open,

    onOpenChange,

}: CreateTrainingDialogProps) {

    const [form, setForm] =
        useState<CreateTrainingJobRequest>(
            DEFAULT_FORM,
        );

    const createMutation =
        useCreateTrainingJob();

    /*
        Existing lookup hooks

        const datasets = useDatasets();
        const providers = useTrainingProviders();
        const models = useModels();

        const snapshots =
            useDatasetSnapshots(
                form.dataset_id,
            );
    */

    const configurations =
        useTrainingConfigurations();

    const modelVersions =
        useModelVersions(
            form.base_model_id || undefined,
        );

    const tokenizers =
        useTokenizers();

    const tokenizerVersions =
        useTokenizerVersions(
            form.tokenizer_version_id ?? undefined,
        );

    useEffect(() => {

        if (!open) {

            setForm(
                DEFAULT_FORM,
            );

        }

    }, [open]);

    const isValid = useMemo(() => {

        return (

            form.dataset_id > 0 &&

            form.dataset_snapshot_id > 0 &&

            form.training_provider_id > 0 &&

            form.training_configuration_id > 0 &&

            form.base_model_id > 0 &&

            form.base_model_version_id > 0 &&

            form.training_type.trim().length > 0

        );

    }, [form]);

    const updateField = <
        K extends keyof CreateTrainingJobRequest
    >(
        key: K,
        value: CreateTrainingJobRequest[K],
    ) => {

        setForm(
            previous => ({

                ...previous,

                [key]: value,

            }),
        );

    };

    return (

        <Dialog
            open={open}
            onOpenChange={onOpenChange}
        >

            <DialogContent className="max-w-4xl">

                <DialogHeader>

                    <DialogTitle>

                        Create Training Job

                    </DialogTitle>

                    <DialogDescription>

                        Configure a new
                        model training job.

                    </DialogDescription>

                </DialogHeader>

                <Card>

                    <div className="grid grid-cols-2 gap-6">

    {/* Dataset */}

    <div className="space-y-2">

        <Label>
            Dataset
        </Label>

        <select
            className="w-full rounded-md border px-3 py-2"
            value={form.dataset_id}
            onChange={(event) => {

                updateField(
                    "dataset_id",
                    Number(event.target.value),
                );

                updateField(
                    "dataset_snapshot_id",
                    0,
                );

            }}
        >

            <option value={0}>
                Select Dataset
            </option>

            {datasets.data?.map(
                (dataset) => (

                    <option
                        key={dataset.id}
                        value={dataset.id}
                    >
                        {dataset.display_name}
                    </option>

                ),
            )}

        </select>

    </div>

    {/* Dataset Snapshot */}

    <div className="space-y-2">

        <Label>
            Dataset Snapshot
        </Label>

        <select
            className="w-full rounded-md border px-3 py-2"
            value={form.dataset_snapshot_id}
            disabled={!form.dataset_id}
            onChange={(event) =>
                updateField(
                    "dataset_snapshot_id",
                    Number(event.target.value),
                )
            }
        >

            <option value={0}>
                Select Snapshot
            </option>

            {snapshots.data?.map(
                (snapshot) => (

                    <option
                        key={snapshot.id}
                        value={snapshot.id}
                    >
                        {snapshot.version}
                    </option>

                ),
            )}

        </select>

    </div>

    {/* Training Provider */}

    <div className="space-y-2">

        <Label>
            Training Provider
        </Label>

        <select
            className="w-full rounded-md border px-3 py-2"
            value={form.training_provider_id}
            onChange={(event) =>
                updateField(
                    "training_provider_id",
                    Number(event.target.value),
                )
            }
        >

            <option value={0}>
                Select Provider
            </option>

            {providers.data?.map(
                (provider) => (

                    <option
                        key={provider.id}
                        value={provider.id}
                    >
                        {provider.display_name}
                    </option>

                ),
            )}

        </select>

    </div>

    {/* Base Model */}

    <div className="space-y-2">

        <Label>
            Base Model
        </Label>

        <select
            className="w-full rounded-md border px-3 py-2"
            value={form.base_model_id}
            onChange={(event) => {

                updateField(
                    "base_model_id",
                    Number(event.target.value),
                );

                updateField(
                    "base_model_version_id",
                    0,
                );

            }}
        >

            <option value={0}>
                Select Base Model
            </option>

            {models.data?.map(
                (model) => (

                    <option
                        key={model.id}
                        value={model.id}
                    >
                        {model.display_name}
                    </option>

                ),
            )}

        </select>

    </div>

</div>

                </Card>

                <div className="flex justify-end gap-2">

                    <Button
                        variant="outline"
                        onClick={() =>
                            onOpenChange(false)
                        }
                    >
                        Cancel
                    </Button>

                    <Button
                        disabled={
                            !isValid ||
                            createMutation.isPending
                        }
                    >
                        Create Job
                    </Button>

                </div>

            </DialogContent>

        </Dialog>

    );

}